import 'package:flutter/material.dart';

class CallScreen extends StatelessWidget {
  const CallScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.video_call, size: 80),
          const SizedBox(height: 16),
          const Text('Voice & Video Calls',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('WebRTC calling layer is ready to be connected.'),
          const SizedBox(height: 20),
          Wrap(
            spacing: 12,
            children: [
              FilledButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.call),
                label: const Text('Voice call'),
              ),
              FilledButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.videocam),
                label: const Text('Video call'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
