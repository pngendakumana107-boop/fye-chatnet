import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController();
  final otp = TextEditingController();
  String? verificationId;
  bool loading = false;

  Future<void> requestOtp() async {
    setState(() => loading = true);
    await AuthService().sendOtp(
      phoneNumber: phone.text.trim(),
      onCodeSent: (id) {
        if (!mounted) return;
        setState(() {
          verificationId = id;
          loading = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('OTP sent by SMS.')),
        );
      },
      onError: (e) {
        if (!mounted) return;
        setState(() => loading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.message ?? 'OTP error')),
        );
      },
    );
  }

  Future<void> verify() async {
    if (verificationId == null) return;
    setState(() => loading = true);
    try {
      await AuthService().verifyOtp(
        verificationId: verificationId!,
        smsCode: otp.text.trim(),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('OTP verification failed: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Center(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  const Icon(Icons.chat_bubble_rounded, size: 72, color: Colors.green),
                  const SizedBox(height: 12),
                  const Text('FYE ChatNet',
                      style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('Connect • Chat • Call • Share'),
                  const SizedBox(height: 40),
                  TextField(
                    controller: phone,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                      labelText: 'Phone number',
                      hintText: '+257 79 00 00 00',
                      prefixIcon: Icon(Icons.phone),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (verificationId != null)
                    TextField(
                      controller: otp,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'OTP code',
                        prefixIcon: Icon(Icons.lock),
                        border: OutlineInputBorder(),
                      ),
                    ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: FilledButton(
                      onPressed: loading
                          ? null
                          : verificationId == null ? requestOtp : verify,
                      child: loading
                          ? const CircularProgressIndicator()
                          : Text(verificationId == null ? 'SEND OTP' : 'VERIFY OTP'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
