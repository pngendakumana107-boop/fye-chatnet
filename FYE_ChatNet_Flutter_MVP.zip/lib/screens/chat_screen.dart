import 'package:flutter/material.dart';

class ChatScreen extends StatelessWidget {
  const ChatScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: const [
        ListTile(
          leading: CircleAvatar(child: Icon(Icons.person)),
          title: Text('FYE ChatNet'),
          subtitle: Text('Your conversations will appear here'),
          trailing: Text('Now'),
        ),
      ],
    );
  }
}
