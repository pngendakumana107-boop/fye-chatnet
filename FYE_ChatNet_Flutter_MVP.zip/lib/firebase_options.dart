// Generated Firebase configuration placeholder.
// Run:
//   dart pub global activate flutterfire_cli
//   flutterfire configure
// This file will then be replaced with your real Firebase project settings.

import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    throw UnsupportedError(
      'Run flutterfire configure to generate real Firebase options.',
    );
  }
}
