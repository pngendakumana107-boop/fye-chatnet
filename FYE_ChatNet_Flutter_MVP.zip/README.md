# FYE ChatNet

FYE ChatNet is a Flutter communication-app MVP.

## Features in this starter
- Phone-number login
- SMS OTP verification
- Firebase authentication state
- Chat UI
- Contacts UI
- Voice/video call UI
- WebRTC dependency prepared
- Firebase Firestore/Storage/FCM dependencies prepared

## Setup

1. Install Flutter and Android Studio.
2. Create a Firebase project.
3. Enable:
   - Authentication > Phone
   - Cloud Firestore
   - Storage
   - Cloud Messaging
4. Install FlutterFire CLI:
   `dart pub global activate flutterfire_cli`
5. From this project folder run:
   `flutterfire configure`
6. Then:
   `flutter pub get`
7. Run:
   `flutter run`

## Important
The call buttons are UI placeholders in this MVP. Real voice/video calling needs:
- WebRTC signaling
- STUN/TURN servers
- Firestore/WebSocket signaling
- Call states and permissions
- Android/iOS microphone and camera permissions

Do not put Firebase server/admin credentials inside the Flutter app.
